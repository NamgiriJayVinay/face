package com.example.privacyview.UI;

import android.Manifest;
import android.animation.Animator;
import android.animation.TimeInterpolator;
import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.ContentValues;
import android.content.Intent;
import com.airbnb.lottie.LottieAnimationView;
import android.content.pm.PackageManager;
import android.content.res.AssetFileDescriptor;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ImageFormat;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.YuvImage;
import android.hardware.camera2.CameraCharacteristics;
import android.media.Image;
import android.media.ImageReader;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.ParcelFileDescriptor;
import android.os.SystemClock;
import android.provider.MediaStore;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.util.Size;
import android.view.Surface;
import android.view.View;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.AccelerateInterpolator;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.OptIn;
import androidx.appcompat.app.AppCompatActivity;
import androidx.camera.core.CameraSelector;
import androidx.camera.core.ExperimentalGetImage;
import androidx.camera.core.ImageAnalysis;
import androidx.camera.core.ImageCapture;
import androidx.camera.core.ImageCaptureException;
import androidx.camera.core.Preview;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.camera.view.PreviewView;
import androidx.cardview.widget.CardView;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.example.privacyview.Drawing.MultiBoxTracker;
import com.example.privacyview.R;
import com.example.privacyview.Face_Recognition.FaceClassifier;
import com.example.privacyview.Face_Recognition.TFLiteFaceRecognition;
import com.example.privacyview.UI.FaceBoxOverlay;
import com.example.privacyview.LiveFeed.ImageUtils;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.face.Face;
import com.google.mlkit.vision.face.FaceDetector;
import com.google.mlkit.vision.face.FaceDetectorOptions;
import com.mikhaellopez.circularprogressbar.CircularProgressBar;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.tensorflow.lite.Interpreter;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileDescriptor;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;

public class FaceDetection extends AppCompatActivity implements FaceBoxOverlay.FaceDetectionListener {
    private static final int PERMISSION_REQUEST_CODE = 1001;
    private static final int MAX_CAPTURES = 2;
    private int sensorOrientation;

    private static final int TF_OD_API_INPUT_SIZE = 160;

    private PreviewView previewView;
    private FaceBoxOverlay faceBoxOverlay;
    private ExecutorService cameraExecutor;
    private FaceDetector faceDetector;
    private ImageCapture imageCapture;
    private AtomicInteger captureCount = new AtomicInteger(0);
    private long lastCaptureTime = 0;
    private static final long CAPTURE_DELAY_MS = 1000; // 1 second delay between captures


    private Bitmap lastProcessedBitmap;
    private final Object bitmapLock = new Object();

    private static final Size PREVIEW_SIZE = new Size(640, 480);


    private byte[][] yuvBytes = new byte[3][];
    private int[] rgbBytes = null;
    private int yRowStride;
    private LinearLayout nameRegistrationLayout;
    private EditText nameEditText;
    private Button registerButton,addAnotherButton,doneButton,face_recognition_check;
    private TextView capturedFacesCountText;
    FaceDetector detector;

    private CardView previewContainer;
    private static final int CROP_SIZE = 1000;
    private static final String KEY_USE_FACING = "use_facing";
    List<FaceClassifier.Recognition> mappedRecognitions;

    private static final int TF_OD_API_INPUT_SIZE2 = 160;
    private List<String> capturedFacePaths = new ArrayList<>();

    // Add these to your existing variable declarations
    private CardView captureProgressCardView;
    private CircularProgressBar circularProgressBar;
    private TextView progressTextView,positionHints;
    private FaceClassifier faceClassifier;

    String name;

    FaceClassifier.Recognition result;
    LinearLayout postRegister;
    private Interpreter tflite;
    private Integer useFacing2 = null;

    Uri image_uri;

    private static final boolean MAINTAIN_ASPECT = false;
    private MultiBoxTracker tracker;

    private Matrix cropToFrameTransform;

    private Matrix frameToCropTransform;
    LottieAnimationView animationView;
    public static HashMap<String, FaceClassifier.Recognition> registered = new HashMap<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(com.example.privacyview.R.layout.live_face);

        animationView = findViewById(R.id.animation_view);


        previewView = findViewById(com.example.privacyview.R.id.preview_view);
        previewContainer = findViewById(com.example.privacyview.R.id.preview_container);
        faceBoxOverlay = findViewById(com.example.privacyview.R.id.face_box_overlay);
        faceBoxOverlay.setFaceDetectionListener(this);
        nameRegistrationLayout = findViewById(com.example.privacyview.R.id.nameRegistrationLayout);
        nameRegistrationLayout.setVisibility(View.INVISIBLE);
        nameEditText = findViewById(com.example.privacyview.R.id.nameEditText);
        positionHints = findViewById(com.example.privacyview.R.id.position_hints);
        positionHints.setVisibility(View.VISIBLE);
        tracker = new MultiBoxTracker(this);
        face_recognition_check=findViewById(com.example.privacyview.R.id.recognition_check);


        Intent intent2 = getIntent();
        useFacing2 = intent2.getIntExtra(KEY_USE_FACING, CameraCharacteristics.LENS_FACING_BACK);
        registerButton = findViewById(com.example.privacyview.R.id.registerButton);

        postRegister = findViewById(com.example.privacyview.R.id.postRegister);

        addAnotherButton =findViewById(com.example.privacyview.R.id.addAnotherButton);
        doneButton = findViewById(com.example.privacyview.R.id.doneButton);
        capturedFacesCountText = findViewById(com.example.privacyview.R.id.capturedFacesCountText);

        // New view initializations
        circularProgressBar = findViewById(com.example.privacyview.R.id.circularProgressBar);
        //====params for circualr progress===
        // or with gradient
        circularProgressBar.setProgressBarColorStart(Color.GRAY);
        circularProgressBar.setProgressBarColorEnd(Color.GREEN);
        circularProgressBar.setProgressBarColorDirection(CircularProgressBar.GradientDirection.TOP_TO_BOTTOM);
        // Set Width
        circularProgressBar.setProgressBarWidth(17f); // in DP
        circularProgressBar.setRoundBorder(true);

        //==============
        progressTextView = findViewById(R.id.progressTextView);
        requestPermissions();

        FaceDetectorOptions options = new FaceDetectorOptions.Builder()
                .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_ACCURATE)
                .setLandmarkMode(FaceDetectorOptions.LANDMARK_MODE_NONE)
                .setClassificationMode(FaceDetectorOptions.CLASSIFICATION_MODE_NONE)
                .build();

        faceDetector = com.google.mlkit.vision.face.FaceDetection.getClient(options);
        cameraExecutor = Executors.newSingleThreadExecutor();
        //TODO initialize FACE Recognition
        try {
            faceClassifier =
                    TFLiteFaceRecognition.create(
                            getAssets(),
                            "facenet.tflite",
                            TF_OD_API_INPUT_SIZE2,
                            false,getApplicationContext());

        } catch (final IOException e) {
            e.printStackTrace();
            Toast toast =
                    Toast.makeText(
                            getApplicationContext(), "Classifier could not be initialized", Toast.LENGTH_SHORT);
            toast.show();
            finish();
        }



        try {
            tflite = new Interpreter(loadModelFile("facenet.tflite"));
        } catch (IOException e) {
            e.printStackTrace();
        }
        faceDetector = com.google.mlkit.vision.face.FaceDetection.getClient(options);
        registerButton.setOnClickListener(v -> registerCapturedFaces());


    }

    private void requestPermissions() {
        String[] permissions;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            permissions = new String[]{
                    Manifest.permission.CAMERA,
                    Manifest.permission.READ_MEDIA_IMAGES
            };
        } else {
            permissions = new String[]{
                    Manifest.permission.CAMERA,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE,
                    Manifest.permission.READ_EXTERNAL_STORAGE
            };
        }

        if (!hasPermissions(permissions)) {
            ActivityCompat.requestPermissions(this, permissions, PERMISSION_REQUEST_CODE);
        } else {
            startCamera();
        }



    }

    private void registerCapturedFaces() {
        name = nameEditText.getText().toString().trim();


        if (name.isEmpty()) {
            Toast.makeText(this, "Please enter a name", Toast.LENGTH_SHORT).show();
            return;
        }

        // Create folder in Documents
        File documentsDir = Environment.getExternalStoragePublicDirectory(
                Environment.DIRECTORY_DOCUMENTS);

        File embeddingsFolder = new File(documentsDir, name + "_Embeddings");
        File facesFolder = new File(documentsDir, name + "_Faces");


        if (!facesFolder.exists()) facesFolder.mkdirs();



        // Move captured faces to the new folder
        for (String sourcePath : capturedFacePaths) {
            File sourceFile = new File(sourcePath);
            File destFile = new File(facesFolder, sourceFile.getName());


            try {
                FileInputStream in = new FileInputStream(sourceFile);
                FileOutputStream out = new FileOutputStream(destFile);

                byte[] buffer = new byte[1024];
                int read;
                while ((read = in.read(buffer)) != -1) {
                    out.write(buffer, 0, read);
                }

                in.close();
                out.close();

                // Optional: Delete original file
                sourceFile.delete();
            } catch (IOException e) {
                e.printStackTrace();
            }



            // Get the list of files in the faces folder
            File[] files = facesFolder.listFiles();

            // Check if the folder contains at least two files
            if (files != null && files.length > 1 && files[1].exists()) {
                // Sort the files to ensure consistent order
                Arrays.sort(files);

                // Get the second file
                File secondFile = files[1];
                //TODO : get an image from the folder
                // Get the URI
                image_uri = Uri.fromFile(secondFile);
                Log.d("CODE", "Second Image URI: " + image_uri.toString());
                Bitmap inputImage = uriToBitmap(image_uri);
                Bitmap rotated = rotateBitmap(inputImage);
//                imageView.setImageBitmap(rotated);
                performFaceDetection(rotated);
                break;

//                // Log its path
//                Log.d("SecondImagePath", "Second image path: " + secondFile.getAbsolutePath());
            } else {
                Log.d("SecondImagePath", "Less than two images in the folder or folder is empty.");
            }




        }




        // Clear the list and reset UI
        capturedFacePaths.clear();
        Toast.makeText(this, "Faces registered for " + name, Toast.LENGTH_LONG).show();
        // Reset for potential new capture

        //TODO : add another person or done buttons and then take below actions
        postRegister.setVisibility(View.VISIBLE);
        registerButton.setVisibility(View.GONE);
        addAnotherButton.setOnClickListener(v -> {
            nameEditText.setText("");
            registerButton.setVisibility(View.VISIBLE);
            animationView.setVisibility(View.INVISIBLE);
            positionHints.setText("Position your face \n in the frame");
            face_recognition_check.setVisibility(View.INVISIBLE);
            previewView.setVisibility(View.VISIBLE);
            showCameraPreview();
            postRegister.setVisibility(View.INVISIBLE);
        });

        doneButton.setOnClickListener(v->{
            this.finishAffinity();
        });




    }

    @SuppressLint("Range")
    public Bitmap rotateBitmap(Bitmap input){
        String[] orientationColumn = {MediaStore.Images.Media.ORIENTATION};
        Cursor cur = getContentResolver().query(image_uri, orientationColumn, null, null, null);
        int orientation = -1;
        if (cur != null && cur.moveToFirst()) {
            orientation = cur.getInt(cur.getColumnIndex(orientationColumn[0]));
        }
        Log.d("tryOrientation",orientation+"");
        Matrix rotationMatrix = new Matrix();
        rotationMatrix.setRotate(orientation);
        Bitmap cropped = Bitmap.createBitmap(input,0,0, input.getWidth(), input.getHeight(), rotationMatrix, true);
        return cropped;
    }
    private Bitmap uriToBitmap(Uri selectedFileUri) {
        try {
            ParcelFileDescriptor parcelFileDescriptor =
                    getContentResolver().openFileDescriptor(selectedFileUri, "r");
            FileDescriptor fileDescriptor = parcelFileDescriptor.getFileDescriptor();
            Bitmap image = BitmapFactory.decodeFileDescriptor(fileDescriptor);

            parcelFileDescriptor.close();
            return image;
        } catch (IOException e) {
            e.printStackTrace();
        }
        return  null;
    }
    private MappedByteBuffer loadModelFile(String modelFileName) throws IOException {
        AssetFileDescriptor fileDescriptor = getAssets().openFd(modelFileName);
        FileInputStream inputStream = new FileInputStream(fileDescriptor.getFileDescriptor());
        FileChannel fileChannel = inputStream.getChannel();
        long startOffset = fileDescriptor.getStartOffset();
        long declaredLength = fileDescriptor.getDeclaredLength();
        Toast.makeText(this,"Loaded Tflite model",Toast.LENGTH_SHORT).show();
        return fileChannel.map(FileChannel.MapMode.READ_ONLY, startOffset, declaredLength);
    }





    private boolean hasPermissions(String[] permissions) {
        for (String permission : permissions) {
            if (ContextCompat.checkSelfPermission(this, permission)
                    != PackageManager.PERMISSION_GRANTED) {
                return false;
            }
        }
        return true;
    }

    @Override
    public void onGoodFaceDetected(Face face, Rect boundingBox) {
        long currentTime = System.currentTimeMillis();
        if (currentTime - lastCaptureTime >= CAPTURE_DELAY_MS &&
                captureCount.get() < MAX_CAPTURES && lastProcessedBitmap != null) {

//            if (captureCount.get()==2){
//                // perform recognition here
//                mappedRecognitions = new ArrayList<>();
//
//                final Rect bounds = face.getBoundingBox();
//                performFaceRecognition(face);
//            }
            synchronized (bitmapLock) {
                if (lastProcessedBitmap != null) {
                    String savedImagePath = cropAndSaveFace(lastProcessedBitmap, face, boundingBox);
                    if (savedImagePath != null) {
                        capturedFacePaths.add(savedImagePath);
                        // Update progress
                        updateCaptureProgress(capturedFacePaths.size());
                    }
//                    if (captureCount.get()==6){
//                        // perform recognition here
//
//                        final Rect bounds = face.getBoundingBox();
//                        performFaceRecognition(face);
//                    }
                }
            }
            lastCaptureTime = currentTime;
        }
    }


    public void performFaceDetection(Bitmap inputImage){
        final Bitmap mutableBmp = inputImage.copy(Bitmap.Config.ARGB_8888,true);
        Canvas canvas = new Canvas(mutableBmp);
        InputImage image = InputImage.fromBitmap(inputImage,0);
        Task<List<Face>> result2 =
                faceDetector.process(image)
                        .addOnSuccessListener(
                                new OnSuccessListener<List<Face>>() {
                                    @Override
                                    public void onSuccess(List<Face> faces) {
                                        for (Face face : faces) {
                                            Rect bounds = face.getBoundingBox();

                                            Paint p = new Paint();
                                            p.setStyle(Paint.Style.STROKE);
                                            p.setStrokeWidth(3);
                                            p.setColor(Color.RED);
                                            canvas.drawRect(bounds,p);
                                            performFaceRecognition(bounds,inputImage);
                                        }
//                                        imageView.setImageBitmap(mutableBmp);

                                    }
                                })
                        .addOnFailureListener(
                                new OnFailureListener() {
                                    @Override
                                    public void onFailure(@NonNull Exception e) {
                                        // Task failed with an exception
                                        // ...
                                    }
                                });

    }


    public void performFaceRecognition(Rect bounds,Bitmap inputImage){
        if(bounds.top<0){
            bounds.top = 0;
        }
        if(bounds.left<0){
            bounds.left = 0;
        }
        if(bounds.right>inputImage.getWidth()){
            bounds.right = inputImage.getWidth()-1;
        }
        if(bounds.bottom>inputImage.getHeight()){
            bounds.bottom = inputImage.getHeight()-1;
        }
        //TODO crop the face
        Bitmap croppedFace = Bitmap.createBitmap(inputImage,
                bounds.left,
                bounds.top,
                bounds.width(),
                bounds.height());
        croppedFace = Bitmap.createScaledBitmap(croppedFace,TF_OD_API_INPUT_SIZE,TF_OD_API_INPUT_SIZE,false);

        //TODO fet the embedding for face
        final long startTime = SystemClock.uptimeMillis();
        result = faceClassifier.recognizeImage(croppedFace, true);
        long lastProcessingTimeMs = SystemClock.uptimeMillis() - startTime;
        if (result != null) {
            //registerFaceDialogue(croppedFace,result);
            faceClassifier.register(name, result);

        }
    }

    private void registerFaceDialogue(Bitmap croppedFace, FaceClassifier.Recognition rec) {
        Dialog dialog = new Dialog(this);
        dialog.setContentView(R.layout.card);
        ImageView ivFace = dialog.findViewById(R.id.dlg_image);
        ImageView tickImageView=dialog.findViewById(R.id.tick_circle);
        EditText nameEd = dialog.findViewById(R.id.dlg_input);
        Button register = dialog.findViewById(R.id.button2);
        TextView dismiss_text=dialog.findViewById(R.id.dismiss_text);
        dismiss_text.setClickable(true);
        dismiss_text.setFocusable(true);
        dismiss_text.setOnClickListener(v -> {
            dialog.dismiss();
        });
        nameEd.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                // check if input text is less 10 digits
                // Not a mandatory field
                if (s.length() < 3){
                    tickImageView.setVisibility(View.INVISIBLE);
                    register.setEnabled(false);
                    register.setEnabled(false);
                    register.setBackgroundResource(R.drawable.rec_low_color);
                }
            }

            @Override
            public void afterTextChanged(Editable s) {
                // check if input text is 3 letter
                if (s.length() >= 3 ){
                    tickImageView.setVisibility(View.VISIBLE);
                    register.setBackgroundResource(R.drawable.rec);
                    register.setEnabled(true);
                    register.setEnabled(true);
                } else {
                    register.setEnabled(false);
                    register.setEnabled(false);
                    register.setBackgroundResource(R.drawable.rec_low_color);
                }
            }
        });


        ivFace.setImageBitmap(croppedFace);
        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String name = nameEd.getText().toString();
                if (name.isEmpty()) {
                    nameEd.setError("Enter Name");
                    return;
                }
                faceClassifier.register(name, rec);
                Toast.makeText(FaceDetection.this, "Face Registered Successfully", Toast.LENGTH_SHORT).show();
                dialog.dismiss();
            }
        });
        dialog.show();
    }
    public void updateCaptureProgress(int capturedCount) {
        // Calculate progress percentage
        int progressPercentage = (capturedCount * 100) / MAX_CAPTURES;

        // Update circular progress bar
        circularProgressBar.setProgress(progressPercentage);

        // Update progress text
        progressTextView.setText(String.format("%d%%", progressPercentage));
        circularProgressBar.setProgressWithAnimation(100f, 2000L,new AccelerateDecelerateInterpolator());

        // If all faces captured, prepare for registration
        if (capturedCount >= MAX_CAPTURES) {
            showNameRegistration();

        }
    }

    public String cropAndSaveFace(Bitmap originalBitmap, Face face, Rect boundingBox) {
        try {
            // Similar to previous implementation, but return the file path
            // Add padding to the bounding box
            int padding = Math.min(boundingBox.width(), boundingBox.height()) / 8;
            Rect paddedBox = new Rect(
                    boundingBox.left - padding,
                    boundingBox.top - padding,
                    boundingBox.right + padding,
                    boundingBox.bottom + padding
            );

            // Ensure the padded box is within image bounds
            paddedBox.left = Math.max(0, paddedBox.left);
            paddedBox.top = Math.max(0, paddedBox.top);
            paddedBox.right = Math.min(originalBitmap.getWidth(), paddedBox.right);
            paddedBox.bottom = Math.min(originalBitmap.getHeight(), paddedBox.bottom);

            // Create the cropped bitmap
            Bitmap croppedBitmap = Bitmap.createBitmap(
                    originalBitmap,
                    paddedBox.left,
                    paddedBox.top,
                    paddedBox.width(),
                    paddedBox.height()
            );

            // Save the cropped face and return its path
            return saveFaceImage(croppedBitmap);

        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public String saveFaceImage(Bitmap faceBitmap) {
        String timestamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault())
                .format(new Date());
        String filename = "FACE_" + timestamp + ".jpg";

        // Using External Storage for easier file management
        File picturesDir = Environment.getExternalStoragePublicDirectory(
                Environment.DIRECTORY_PICTURES);
        File tempFacesDir = new File(picturesDir, "TempFaces");

        if (!tempFacesDir.exists()) {
            tempFacesDir.mkdirs();
        }
        //cropped face
        File imageFile = new File(tempFacesDir, filename);

        // face recognition logic---
        //faceBitmap = Bitmap.createScaledBitmap(faceBitmap,160,160,false);
        //FaceClassifier.Recognition recognition = faceClassifier.recognizeImage(faceBitmap,true);



        //------


        try (FileOutputStream out = new FileOutputStream(imageFile)) {
            faceBitmap.compress(Bitmap.CompressFormat.JPEG, 100, out);

            int count = captureCount.incrementAndGet();
            runOnUiThread(() -> {
                capturedFacesCountText.setText("Faces Captured: " + count);

                // When max captures reached, switch to name registration
                if (count >= MAX_CAPTURES) {
                    showNameRegistration();
                    // after this we get the name as name is global
                    //saveFaceEmbeddings(recognition);
                }
            });

            return imageFile.getAbsolutePath();
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    private void saveFaceEmbeddings(FaceClassifier.Recognition recognition) {
        faceClassifier.register(name,recognition);
    }

    @Override
    public void onFaceLost() {
        // Face is no longer detected or not in good position
    }

    private void captureFace(RectF faceBounds) {
        if (imageCapture == null) return;

        String timestamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault())
                .format(new Date());
        String filename = "FACE_" + timestamp + ".jpg";

        ContentValues contentValues = new ContentValues();
        contentValues.put(MediaStore.MediaColumns.DISPLAY_NAME, filename);
        contentValues.put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg");
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            contentValues.put(MediaStore.MediaColumns.RELATIVE_PATH,
                    Environment.DIRECTORY_PICTURES + "/FaceCaptures");
        }

        ImageCapture.OutputFileOptions outputFileOptions =
                new ImageCapture.OutputFileOptions.Builder(
                        getContentResolver(),
                        MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                        contentValues
                ).build();

        imageCapture.takePicture(outputFileOptions, cameraExecutor,
                new ImageCapture.OnImageSavedCallback() {
                    @Override
                    public void onImageSaved(@NonNull ImageCapture.OutputFileResults output) {
                        int count = captureCount.incrementAndGet();
                        runOnUiThread(() -> {
                            Toast.makeText(FaceDetection.this,
                                    "Captured image " + count + " of " + MAX_CAPTURES,
                                    Toast.LENGTH_SHORT).show();

                            if (count >= MAX_CAPTURES) {
                                Toast.makeText(FaceDetection.this,
                                        "All captures completed!",
                                        Toast.LENGTH_LONG).show();

                                // registration success here
                            }
                        });
                    }

                    @Override
                    public void onError(@NonNull ImageCaptureException exception) {
                        runOnUiThread(() -> Toast.makeText(FaceDetection.this,
                                "Error capturing image: " + exception.getMessage(),
                                Toast.LENGTH_SHORT).show());
                    }
                });
    }

    private void startCamera() {
        ProcessCameraProvider.getInstance(this).addListener(() -> {
            try {
                ProcessCameraProvider cameraProvider = ProcessCameraProvider.getInstance(this).get();
                bindCameraUseCases(cameraProvider);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }, ContextCompat.getMainExecutor(this));
    }

    private void bindCameraUseCases(ProcessCameraProvider cameraProvider) {
        Preview preview = new Preview.Builder().build();

        imageCapture = new ImageCapture.Builder()
                .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
                .build();

        ImageAnalysis imageAnalysis = new ImageAnalysis.Builder()
                .setTargetResolution(new Size(640, 480))
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .build();

        imageAnalysis.setAnalyzer(cameraExecutor, imageProxy -> {
            try {
                // Get the image format
                @OptIn(markerClass = ExperimentalGetImage.class) @SuppressWarnings("ConstantConditions")
                Image image = imageProxy.getImage();
                if (image == null) {
                    imageProxy.close();
                    return;
                }

                // Convert Image to Bitmap
                Bitmap bitmap = imageToBitmap(image);

                // Handle rotation
                int rotation = imageProxy.getImageInfo().getRotationDegrees();
                if (rotation != 0) {
                    cropToFrameTransform = new Matrix();
                    cropToFrameTransform.postRotate(rotation);
                    bitmap = Bitmap.createBitmap(
                            bitmap,
                            0,
                            0,
                            bitmap.getWidth(),
                            bitmap.getHeight(),
                            cropToFrameTransform,
                            true
                    );
                }
                sensorOrientation = rotation - getScreenOrientation();

                frameToCropTransform =
                        ImageUtils.getTransformationMatrix(
                                0, 0,
                                bitmap.getWidth(),
                                bitmap.getHeight(),
                                sensorOrientation, MAINTAIN_ASPECT);
                // we will get every face image bitmap here :
                cropToFrameTransform = new Matrix();
                frameToCropTransform.invert(cropToFrameTransform);
                tracker.setFrameConfiguration(0, 0, sensorOrientation);

                synchronized (bitmapLock) {
                    lastProcessedBitmap = bitmap;
                }

                // Create InputImage from Image object directly
                InputImage inputImage = InputImage.fromMediaImage(image, rotation);

                Bitmap finalBitmap = bitmap;
                faceDetector.process(inputImage)
                        .addOnSuccessListener(faces -> {
                            faceBoxOverlay.setImageSourceInfo(
                                    finalBitmap.getWidth(),
                                    finalBitmap.getHeight(),
                                    CameraSelector.LENS_FACING_FRONT
                            );
                            faceBoxOverlay.setFaces(faces);
                        })
                        .addOnCompleteListener(task -> imageProxy.close());

            } catch (Exception e) {
                imageProxy.close();
                e.printStackTrace();
            }
        });

        CameraSelector cameraSelector = new CameraSelector.Builder()
                .requireLensFacing(CameraSelector.LENS_FACING_FRONT)
                .build();

        try {
//            cameraProvider.unbindAll();
            cameraProvider.bindToLifecycle(
                    this,
                    cameraSelector,
                    preview,
                    imageCapture,
                    imageAnalysis
            );

            preview.setSurfaceProvider(previewView.getSurfaceProvider());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    protected int getScreenOrientation() {
        switch (getWindowManager().getDefaultDisplay().getRotation()) {
            case Surface.ROTATION_270:
                return 270;
            case Surface.ROTATION_180:
                return 180;
            case Surface.ROTATION_90:
                return 90;
            default:
                return 0;
        }
    }

    private void showNameRegistration() {
        // Hide camera preview
        previewView.setVisibility(View.INVISIBLE);

        // Show name registration layout
        nameRegistrationLayout.setVisibility(View.VISIBLE);

        // Hide capture progress
        progressTextView.setVisibility(View.INVISIBLE);

//        positionHints.setVisibility(View.GONE);
        positionHints.setText("Face Captured \nSuccessfully");

        animationView.setVisibility(View.VISIBLE);


        nameEditText.requestFocus();
        InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        if (imm!=null){
            imm.showSoftInput(nameEditText,InputMethodManager.SHOW_IMPLICIT);
        }


        face_recognition_check.setVisibility(View.VISIBLE);
        face_recognition_check.setOnClickListener((v)->{
            redirectToRecognition();
        });
    }
    private void redirectToRecognition() {
        // Create an Intent to start the second Activity
        Intent intent = new Intent(this, MainActivity.class);
        // Start the second Activity
        startActivity(intent);
    }

    private void showCameraPreview() {

        // Reset progress
        circularProgressBar.setProgress(0);
        progressTextView.setText("0%");

        // Hide name registration layout
        nameRegistrationLayout.setVisibility(View.GONE);

        // Show camera preview
        previewContainer.setVisibility(View.VISIBLE);

        progressTextView.setVisibility(View.VISIBLE);

        positionHints.setVisibility(View.VISIBLE);


        // Reset capture count
        captureCount.set(0);
        capturedFacesCountText.setText("Faces Captured: 0");
        capturedFacePaths.clear();
    }

    // Add this helper method to convert Image to Bitmap
    private Bitmap imageToBitmap(Image image) {
        Image.Plane[] planes = image.getPlanes();
        ByteBuffer yBuffer = planes[0].getBuffer();
        ByteBuffer uBuffer = planes[1].getBuffer();
        ByteBuffer vBuffer = planes[2].getBuffer();

        int ySize = yBuffer.remaining();
        int uSize = uBuffer.remaining();
        int vSize = vBuffer.remaining();

        byte[] nv21 = new byte[ySize + uSize + vSize];

        // U and V are swapped
        yBuffer.get(nv21, 0, ySize);
        vBuffer.get(nv21, ySize, vSize);
        uBuffer.get(nv21, ySize + vSize, uSize);

        YuvImage yuvImage = new YuvImage(nv21, ImageFormat.NV21, image.getWidth(), image.getHeight(), null);
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        yuvImage.compressToJpeg(new Rect(0, 0, yuvImage.getWidth(), yuvImage.getHeight()), 100, out);

        byte[] imageBytes = out.toByteArray();
        return BitmapFactory.decodeByteArray(imageBytes, 0, imageBytes.length);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 &&
                    grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                startCamera();
            } else {
                Toast.makeText(this, "Permissions required to use the app",
                        Toast.LENGTH_LONG).show();
                finish();
            }
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        cameraExecutor.shutdown();
    }
}
