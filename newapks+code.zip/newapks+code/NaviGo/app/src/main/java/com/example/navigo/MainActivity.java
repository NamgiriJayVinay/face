package com.example.navigo;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private static final int PERMISSIONS_REQUEST_LOCATION = 100;
    private static final int PERMISSIONS_REQUEST_BACKGROUND_LOCATION = 101;
    private TextView statusTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        statusTextView = findViewById(R.id.status_text);

        // Check and request location permissions
        checkAndRequestLocationPermissions();
    }

    private void checkAndRequestLocationPermissions() {
        List<String> permissionsToRequest = new ArrayList<>();

        // Check for basic location permissions
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            permissionsToRequest.add(Manifest.permission.ACCESS_FINE_LOCATION);
        }

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            permissionsToRequest.add(Manifest.permission.ACCESS_COARSE_LOCATION);
        }

        // Request basic location permissions if needed
        if (!permissionsToRequest.isEmpty()) {
            statusTextView.setText("Requesting location permissions...");
            ActivityCompat.requestPermissions(this,
                    permissionsToRequest.toArray(new String[0]),
                    PERMISSIONS_REQUEST_LOCATION);
        } else {
            // Basic location permissions already granted, check for background location
            checkBackgroundLocationPermission();
        }
    }

    private void checkBackgroundLocationPermission() {
        // Background location permission is only available in Android 10 (API 29) and higher
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_BACKGROUND_LOCATION)
                    != PackageManager.PERMISSION_GRANTED) {
                statusTextView.setText("Requesting background location permission...");

                // Request background location permission
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.ACCESS_BACKGROUND_LOCATION},
                        PERMISSIONS_REQUEST_BACKGROUND_LOCATION);
            } else {
                // All permissions granted
                statusTextView.setText("All location permissions granted!");
            }
        } else {
            // For devices with Android 9 (API 28) or lower, all location permissions granted
            statusTextView.setText("All location permissions granted!");
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions,
                                           int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == PERMISSIONS_REQUEST_LOCATION) {
            boolean allGranted = true;
            for (int result : grantResults) {
                if (result != PackageManager.PERMISSION_GRANTED) {
                    allGranted = false;
                    break;
                }
            }

            if (allGranted) {
                // All basic location permissions granted, check for background location
                Toast.makeText(this, "Location permissions granted!", Toast.LENGTH_SHORT).show();
                checkBackgroundLocationPermission();
            } else {
                // Some or all permissions were denied
                statusTextView.setText("Location permissions denied.\nApp functionality will be limited.");
                Toast.makeText(this, "Location permissions denied", Toast.LENGTH_SHORT).show();
            }
        } else if (requestCode == PERMISSIONS_REQUEST_BACKGROUND_LOCATION) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Background location permission granted
                statusTextView.setText("All location permissions granted (including background)!");
                Toast.makeText(this, "Background location permission granted!", Toast.LENGTH_SHORT).show();
            } else {
                // Background location permission denied
                statusTextView.setText("Basic location permissions granted,\nbut background location denied.");
                Toast.makeText(this, "Background location permission denied", Toast.LENGTH_SHORT).show();
            }
        }
    }
}