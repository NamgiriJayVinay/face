package com.example.zapconnect;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private static final int PERMISSIONS_REQUEST_READ_CALL_LOG = 100;
    private TextView statusTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        statusTextView = findViewById(R.id.status_text);

        // Check if we already have the permission
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_CALL_LOG)
                !=  PackageManager.PERMISSION_GRANTED) {
            // If we don't have permission, request it
            requestCallLogPermission();
        } else {
            // We already have permission
            statusTextView.setText("Call log permission is already granted!");
        }
    }

    private void requestCallLogPermission() {
        if (ActivityCompat.shouldShowRequestPermissionRationale(this,
                Manifest.permission.READ_CALL_LOG)) {
            // Explain why the permission is needed
            statusTextView.setText("Call log permission is needed to display your call history.");

            // Then request the permission
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.READ_CALL_LOG},
                    PERMISSIONS_REQUEST_READ_CALL_LOG);
        } else {
            // No explanation needed, request the permission directly
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.READ_CALL_LOG},
                    PERMISSIONS_REQUEST_READ_CALL_LOG);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions,
                                           int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == PERMISSIONS_REQUEST_READ_CALL_LOG) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission was granted
                statusTextView.setText("Call log permission granted!\nYou can now access call logs.");
                Toast.makeText(this, "Call log permission granted!", Toast.LENGTH_SHORT).show();
            } else {
                // Permission was denied
                statusTextView.setText("Call log permission denied.\nApp functionality will be limited.");
                Toast.makeText(this, "Call log permission denied", Toast.LENGTH_SHORT).show();
            }
        }
    }
}