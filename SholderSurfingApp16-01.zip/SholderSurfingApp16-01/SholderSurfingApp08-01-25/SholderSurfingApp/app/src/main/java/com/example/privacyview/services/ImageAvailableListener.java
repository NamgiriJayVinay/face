package com.example.privacyview.services;

import android.media.Image;
import android.media.ImageReader;
import android.util.Log;

public class ImageAvailableListener implements ImageReader.OnImageAvailableListener {

    private static final String TAG = "ImageAvailableListener";

    @Override
    public void onImageAvailable(ImageReader reader) {
        Image image = null;
        try {
            image = reader.acquireLatestImage();
            if (image != null) {
                // Process the image here
                Log.d(TAG, "Image available for processing.");
            }
        } catch (Exception e) {
            Log.e(TAG, "Error processing image: " + e.getMessage());
        } finally {
            if (image != null) {
                image.close();
            }
        }
    }
}
