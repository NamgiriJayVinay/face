package com.example.privacyview.services;

import android.Manifest;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.ImageFormat;
import android.graphics.Matrix;
import android.graphics.Rect;
import android.graphics.RectF;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraDevice;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.CaptureRequest;
import android.media.Image;
import android.media.ImageReader;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.Surface;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;

import com.example.privacyview.Drawing.MultiBoxTracker;
import com.example.privacyview.Drawing.OverlayView;
import com.example.privacyview.Face_Recognition.FaceClassifier;
import com.example.privacyview.Face_Recognition.TFLiteFaceRecognition;
import com.example.privacyview.LiveFeed.ImageUtils;
import com.example.privacyview.R;
import com.example.privacyview.UI.MainActivity;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.face.Face;
import com.google.mlkit.vision.face.FaceDetection;
import com.google.mlkit.vision.face.FaceDetector;
import com.google.mlkit.vision.face.FaceDetectorOptions;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;

public class FloatingWindowService extends Service {

    private static final String TAG = "FloatingWindowService";
    private Matrix frameToCropTransform;
    private boolean isProcessingFrame = false;
    private Runnable imageConverter;
    private WindowManager windowManager;

    private Matrix cropToFrameTransform;
    private Bitmap rgbFrameBitmap;

    private Runnable postInferenceCallback;

    private static final int TF_OD_API_INPUT_SIZE2 = 160;
    int previewHeight = 0,previewWidth = 0;
    boolean registerFace = false;

    private View floatingView;
    private SurfaceView surfaceView;
    private static final int CROP_SIZE = 1000;
    boolean isOverlayActive = false;

    private FaceClassifier faceClassifier;

    private OverlayView trackingOverlay;

    private CameraDevice cameraDevice;
    private ImageReader imageReader;
    private Handler backgroundHandler;
    private HandlerThread backgroundThread;

    Bitmap croppedBitmap;
    private byte[][] yuvBytes = new byte[3][];
    private int[] rgbBytes = null;
    private int yRowStride;
    private Integer useFacing = null;

    TextView widgetText;

    private FaceDetector faceDetector;
    private MultiBoxTracker tracker;
    private int sensorOrientation;

    private static final boolean MAINTAIN_ASPECT = false;
    private static final float TEXT_SIZE_DIP = 10;
    private Bitmap rgbBitmap;

    @Override
    public void onCreate() {
        super.onCreate();
        try {
            faceClassifier =
                    TFLiteFaceRecognition.create(
                            getAssets(),
                            "facenet.tflite",
                            TF_OD_API_INPUT_SIZE2,
                            false, getApplicationContext());

        } catch (final IOException e) {
            e.printStackTrace();
            Toast.makeText(getApplicationContext(), "Classifier could not be initialized", Toast.LENGTH_SHORT).show();
        }

        // Inflate the floating widget layout
        floatingView = LayoutInflater.from(this).inflate(R.layout.floating_widget, null);
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        trackingOverlay = (OverlayView) floatingView.findViewById(R.id.tracking_overlay);
        trackingOverlay.addCallback(
                new OverlayView.DrawCallback() {
                    @Override
                    public void drawCallback(final Canvas canvas) {
                        tracker.draw(canvas);
                        Log.d("tryDrawRect","inside draw");

                    }
                });

        // Add the floating view to the WindowManager
        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                android.graphics.PixelFormat.TRANSLUCENT);
        params.x = 0;
        params.y = 100;

        windowManager.addView(floatingView, params);

        // Add touch listener to make the widget draggable
        floatingView.setOnTouchListener(new View.OnTouchListener() {


            private int lastAction;
            private int initialX, initialY;
            private float initialTouchX, initialTouchY;

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        initialX = params.x;
                        initialY = params.y;
                        initialTouchX = event.getRawX();
                        initialTouchY = event.getRawY();
                        lastAction = MotionEvent.ACTION_DOWN;
                        return true;

                    case MotionEvent.ACTION_MOVE:
                        params.x = initialX + (int) (event.getRawX() - initialTouchX);
                        params.y = initialY + (int) (event.getRawY() - initialTouchY);

                        windowManager.updateViewLayout(floatingView, params);
                        lastAction = MotionEvent.ACTION_MOVE;
                        return true;

                    case MotionEvent.ACTION_UP:
                        if (lastAction == MotionEvent.ACTION_MOVE) {
                            return true;
                        }
                        break;
                }
                return false;
            }
        });

        surfaceView = floatingView.findViewById(R.id.surface_view);
        surfaceView.getHolder().addCallback(new SurfaceHolder.Callback() {
            @Override
            public void surfaceCreated(@NonNull SurfaceHolder holder) {
                setupCamera();
            }

            @Override
            public void surfaceChanged(@NonNull SurfaceHolder holder, int format, int width, int height) {}

            @Override
            public void surfaceDestroyed(@NonNull SurfaceHolder holder) {}
        });

        trackingOverlay = floatingView.findViewById(R.id.tracking_overlay);
        widgetText = floatingView.findViewById(R.id.camera_text2);

        setupCamera();

        startBackgroundThread();

        FaceDetectorOptions options = new FaceDetectorOptions.Builder()
                .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_ACCURATE)
                .setLandmarkMode(FaceDetectorOptions.LANDMARK_MODE_NONE)
                .setClassificationMode(FaceDetectorOptions.CLASSIFICATION_MODE_NONE)
                .build();
        faceDetector = FaceDetection.getClient(options);

        tracker = new MultiBoxTracker(this);

        trackingOverlay.addCallback(canvas -> tracker.draw(canvas));
    }
//    public void saveImage(Bitmap imageBitMap ,String fileName){
//        // Load the image from resources
//        Bitmap bitmap = imageBitMap;
//
//        // Create a file to save the image
//        File file = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS), fileName+".JPEG");
//        if(!file.exists()){
//            Log.i("ImageSave","File not found");
//
//
//            try {
//
//                // Save the image to the file
//                FileOutputStream fos = new FileOutputStream(file);
//                bitmap.compress(Bitmap.CompressFormat.JPEG, 100, fos);
//                fos.flush();
//                fos.close();
//
//                Log.d("ImageSave", "Image saved successfully: " + file.getAbsolutePath());
//            } catch (IOException e) {
//                e.printStackTrace();
//                Log.e("ImageSave", "Failed to save image: " + e.getMessage());
//            }
//        }
//    }


    public void setupCamera() {
        CameraManager cameraManager = (CameraManager) getSystemService(Context.CAMERA_SERVICE);
        try {
            String cameraId = getFrontCameraId(cameraManager);
            if (cameraId == null) {
                Log.e(TAG, "No front camera found");
                return;
            }


            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                Log.e(TAG, "Camera permission not granted");
                return;
            }
            cameraManager.openCamera(cameraId, new CameraDevice.StateCallback() {
                @Override
                public void onOpened(@NonNull CameraDevice camera) {
                    cameraDevice = camera;
                    startCameraPreview();
                }

                @Override
                public void onDisconnected(@NonNull CameraDevice camera) {
                    camera.close();
                }

                @Override
                public void onError(@NonNull CameraDevice camera, int error) {
                    Log.e(TAG, "Camera error: " + error);
                }
            }, backgroundHandler);

        } catch (CameraAccessException e) {
            Log.e(TAG, "Error setting up camera: " + e.getMessage());
        }

        // onImageAvailable logic
        imageReader = ImageReader.newInstance(640, 480, ImageFormat.YUV_420_888, 2);
        imageReader.setOnImageAvailableListener(reader -> {
            try (Image image = reader.acquireLatestImage()) {
                Log.d("CAMERA", "aquired latest image of size height :  "+image.getHeight()+" width of : "+image.getWidth());


                if (image == null) {
                    Log.d("JAYYY", "Got image as null");
                    return;
                }

                if (isProcessingFrame) {
                    image.close();
                    Log.d("EXCEPTION", "isprocessing is true");
                }


                performFaceDetection(image);
                postInferenceCallback =
                        new Runnable() {
                            @Override
                            public void run() {
                                image.close();
                                isProcessingFrame = false;
                            }
                        };

            }catch (final Exception e) {
                Log.d("EXCEPTION",e.getMessage()+"abc ");
                return;
            }

        }, backgroundHandler);

    }



    public void performFaceDetection(Image image){
//        imageConverter.run();



        previewWidth = image.getWidth();
        previewHeight = image.getHeight();

        Log.d("JAYYY123", "started image conversion" + previewHeight + " " + previewWidth);
        tracker.setFrameConfiguration(previewWidth, previewHeight, 0);

        isProcessingFrame = true;
        final Image.Plane[] planes = image.getPlanes();
        fillBytes(planes, yuvBytes);
        yRowStride = planes[0].getRowStride();
        final int uvRowStride = planes[1].getRowStride();
        final int uvPixelStride = planes[1].getPixelStride();
        int cropSize = CROP_SIZE;

        if (rgbBytes == null) {
            rgbBytes = new int[previewWidth * previewHeight];
        }
        ImageUtils.convertYUV420ToARGB8888(
                yuvBytes[0],
                yuvBytes[1],
                yuvBytes[2],
                previewWidth,
                previewHeight,
                yRowStride,
                uvRowStride,
                uvPixelStride,
                rgbBytes);

        Log.d("JAYYY1", "completed face image conversion");

        //All creations here
        rgbFrameBitmap = Bitmap.createBitmap(previewWidth, previewHeight, Bitmap.Config.ARGB_8888);
        croppedBitmap = Bitmap.createBitmap(cropSize, cropSize, Bitmap.Config.ARGB_8888);
        frameToCropTransform =
                ImageUtils.getTransformationMatrix(
                        previewWidth, previewHeight,
                        cropSize, cropSize,
                        sensorOrientation, MAINTAIN_ASPECT);

        cropToFrameTransform = new Matrix();
        frameToCropTransform.invert(cropToFrameTransform);





        rgbFrameBitmap.setPixels(rgbBytes, 0, previewWidth, 0, 0, previewWidth, previewHeight);

        Log.d("JAYYY1", "completed RGB framebit creation");

        final Canvas canvas = new Canvas(croppedBitmap);
        canvas.drawBitmap(rgbFrameBitmap, frameToCropTransform, null);


        Log.d("JAYYY1", "canvas created adn drawn sqaure to face");

        new Handler().post(new Runnable() {
            @Override
            public void run() {
                mappedRecognitions = new ArrayList<>();
                Matrix matrix = new Matrix();
                matrix.postRotate(270);
                croppedBitmap = Bitmap.createBitmap
                        (croppedBitmap,0,0,croppedBitmap.getWidth(),croppedBitmap.getHeight(),matrix,true);
                InputImage image = InputImage.fromBitmap(croppedBitmap,0);
//                saveImage(croppedBitmap,"modeltwo"+Math.random());
                faceDetector.process(image)
                        .addOnSuccessListener(
                                new OnSuccessListener<List<Face>>() {
                                    @Override
                                    public void onSuccess(List<Face> faces) {
                                        if(faces.isEmpty()){
                                            if(isOverlayActive){
                                                stopForegroundService();
                                                isOverlayActive = false;
                                            }

                                        }

                                        for(Face face:faces) {
                                            final Rect bounds = face.getBoundingBox();
                                            Log.i("JAYYY12", "Found face");
                                            Log.i("JAYYY12", "Bounding box of face is "+bounds);

                                            performFaceRecognition(face);
                                        }
                                        registerFace = false;
                                       // tracker.trackResults(mappedRecognitions, 10);
                                       // trackingOverlay.postInvalidate();
                                       // postInferenceCallback.run();
                                        postInferenceCallback.run();

                                    }
                                })
                        .addOnFailureListener(
                                new OnFailureListener() {
                                    @Override
                                    public void onFailure(@NonNull Exception e) {
                                        // Task failed with an exception
                                        // ...
                                    }
                                });



            }
        });
    }


    protected void fillBytes(final Image.Plane[] planes, final byte[][] yuvBytes) {
        // Because of the variable row stride it's not possible to know in
        // advance the actual necessary dimensions of the yuv planes.
        Log.d("JAYYY1", "started filling bytes");

        for (int i = 0; i < planes.length; ++i) {
            final ByteBuffer buffer = planes[i].getBuffer();
            if (yuvBytes[i] == null) {
                yuvBytes[i] = new byte[buffer.capacity()];
            }
            buffer.get(yuvBytes[i]);
        }
        Log.d("JAYYY1", "completed filling bytes");

    }

    private void startCameraPreview() {
        try {
            CaptureRequest.Builder requestBuilder = cameraDevice.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW);

            Surface previewSurface = surfaceView.getHolder().getSurface();
            requestBuilder.addTarget(previewSurface);
            requestBuilder.addTarget(imageReader.getSurface());

            cameraDevice.createCaptureSession(List.of(previewSurface, imageReader.getSurface()), new CameraCaptureSession.StateCallback() {
                @Override
                public void onConfigured(@NonNull CameraCaptureSession session) {
                    try {
                        session.setRepeatingRequest(requestBuilder.build(), null, backgroundHandler);
                        Log.i(TAG, "Camera preview started");
                    } catch (CameraAccessException e) {
                        Log.e(TAG, "Error starting camera preview: " + e.getMessage());
                    }
                }

                @Override
                public void onConfigureFailed(@NonNull CameraCaptureSession session) {
                    Log.e(TAG, "Failed to configure camera session");
                }
            }, backgroundHandler);
        } catch (CameraAccessException e) {
            Log.e(TAG, "Error starting camera preview: " + e.getMessage());
        }
    }


    List<FaceClassifier.Recognition> mappedRecognitions;

    public void performFaceRecognition(Face face) {
        Log.d("JAYYY123", "Started Face RECOGNITION");

        Rect bounds = face.getBoundingBox();
        if (bounds.top < 0) bounds.top = 0;
        if (bounds.left < 0) bounds.left = 0;

        if (bounds.left + bounds.width() > croppedBitmap.getWidth()) bounds.right = croppedBitmap.getWidth() - 1;
        if (bounds.top + bounds.height() > croppedBitmap.getHeight()) bounds.bottom = croppedBitmap.getHeight() - 1;

        Bitmap crop = Bitmap.createBitmap(croppedBitmap,
                bounds.left,
                bounds.top,
                bounds.width(),
                bounds.height());
        crop = Bitmap.createScaledBitmap(crop, TF_OD_API_INPUT_SIZE2, TF_OD_API_INPUT_SIZE2, false);


        final FaceClassifier.Recognition Pillresult = faceClassifier.recognizeImageFromPill(crop);
        String title = "Unknown";
        float confidence = 0;
        if (Pillresult != null) {
            if (registerFace) {
                // showNameRegistration();
            } else {
                if (Pillresult.getDistance() < 0.75f) {
                    confidence = Pillresult.getDistance();
                    title = Pillresult.getTitle();
                }
                Log.i("JAYYY123", "NAME : " + title+" Confidence : "+confidence + " " + Pillresult.getDistance());
                if(title.equals("Unknown")){
                    if(!isOverlayActive){
                        startForegroundService();
                        isOverlayActive = true;
                    }
                }else{
                    if(isOverlayActive) {
                        stopForegroundService();
                        isOverlayActive =false;
                    }
                }
            }
        } else {
            Log.d("FaceRecognition", "No result from face classifier.");
            // Handle case where recognition failed
        }

    }
    public void startForegroundService() {
        Intent serviceIntent = new Intent(this, PrivacyViewForegroundService.class);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(serviceIntent);
        } else {
            startService(serviceIntent);
        }
    }
    public void stopForegroundService() {
        Intent serviceIntent = new Intent(this, PrivacyViewForegroundService.class);
        stopService(serviceIntent);
    }
    private String getFrontCameraId(CameraManager manager) throws CameraAccessException {
        for (String cameraId : manager.getCameraIdList()) {
            CameraCharacteristics characteristics = manager.getCameraCharacteristics(cameraId);
            if (characteristics.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_FRONT) {
                return cameraId;
            }
        }
        return null;
    }

    private void startBackgroundThread() {
        backgroundThread = new HandlerThread("CameraBackground");
        backgroundThread.start();
        backgroundHandler = new Handler(backgroundThread.getLooper());
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (cameraDevice != null) cameraDevice.close();
        if (backgroundThread != null) backgroundThread.quitSafely();
        if (floatingView != null) windowManager.removeView(floatingView);
        if (faceDetector != null) faceDetector.close();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}