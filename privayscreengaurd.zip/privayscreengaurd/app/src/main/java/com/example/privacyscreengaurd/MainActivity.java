package com.example.privacyscreengaurd;

import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

import com.example.privacyscreengaurd.R;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button startButton = findViewById(R.id.start_button);
        Button stopButton = findViewById(R.id.stop_button);

        startButton.setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(MainActivity.this)) {
                Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION);
                startActivity(intent);
            } else {
                startService(new Intent(MainActivity.this, com.example.privacyscreengaurd.PrivacyScreenService.class));
            }
        });

        stopButton.setOnClickListener(v -> stopService(new Intent(MainActivity.this, com.example.privacyscreengaurd.PrivacyScreenService.class)));

        // Check overlay permission
        if (!Settings.canDrawOverlays(this)) {
            Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION);
            startActivity(intent);
        }

        // Start the floating window service
        findViewById(R.id.start_service_button).setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, FloatingWindowService.class);
            startService(intent);
        });

        // Stop the floating window service
        findViewById(R.id.stop_service_button).setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, FloatingWindowService.class);
            stopService(intent);
        });

    }
}
