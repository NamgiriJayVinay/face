package com.example.privacyscreengaurd;

import android.app.Service;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.opengl.GLSurfaceView;
import android.os.IBinder;
import android.view.WindowManager;

import com.example.privacyscreengaurd.PrivacyScreenRenderer;

public class PrivacyScreenService extends Service {

    private WindowManager windowManager;
    private GLSurfaceView glSurfaceView;

    @Override
    public void onCreate() {
        super.onCreate();

        // Initialize WindowManager
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);

        // Create GLSurfaceView for custom rendering
        glSurfaceView = new GLSurfaceView(this);
        glSurfaceView.setEGLContextClientVersion(2);
        glSurfaceView.setRenderer(new PrivacyScreenRenderer()); // Implement this class
        glSurfaceView.setZOrderOnTop(true);
        glSurfaceView.getHolder().setFormat(PixelFormat.TRANSLUCENT);

        // Set layout parameters for the overlay
        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                PixelFormat.TRANSLUCENT
        );

        // Add the GLSurfaceView to the WindowManager
        windowManager.addView(glSurfaceView, params);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (glSurfaceView != null) {
            windowManager.removeView(glSurfaceView);
        }
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
