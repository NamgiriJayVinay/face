package com.example.privacyview.services;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.AssetFileDescriptor;
import android.graphics.Bitmap;
import android.graphics.ImageFormat;
import android.graphics.Matrix;
import android.graphics.Rect;
import android.graphics.RectF;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraDevice;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.CaptureRequest;
import android.media.ImageReader;

import android.media.Image;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.Surface;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;

import android.view.WindowManager;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.core.app.ActivityCompat;
import com.example.privacyview.Drawing.MultiBoxTracker;
import com.example.privacyview.Drawing.OverlayView;
import com.example.privacyview.Face_Recognition.FaceClassifier;
import com.example.privacyview.Face_Recognition.TFLiteFaceRecognition;
import com.example.privacyview.LiveFeed.ImageUtils;
import com.example.privacyview.R;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.face.Face;
import com.google.mlkit.vision.face.FaceDetection;
import com.google.mlkit.vision.face.FaceDetector;
import com.google.mlkit.vision.face.FaceDetectorOptions;
import org.tensorflow.lite.Interpreter;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
import java.util.ArrayList;
import java.util.List;

public class FloatingWindowService extends Service {

    private static final String TAG = "FloatingWindowService";
    private Matrix frameToCropTransform;

    private WindowManager windowManager;

    private Matrix cropToFrameTransform;

    private Runnable postInferenceCallback;

    private static final int TF_OD_API_INPUT_SIZE2 = 160;

    private View floatingView;
    private SurfaceView surfaceView;
    private static final int CROP_SIZE = 1000;


    private FaceClassifier faceClassifier;

    private OverlayView trackingOverlay;

    private CameraDevice cameraDevice;
    private ImageReader imageReader;
    private Handler backgroundHandler;
    private HandlerThread backgroundThread;
    Bitmap croppedBitmap;

    private Integer useFacing = null;

    TextView widgetText;

    private FaceDetector faceDetector;
    private MultiBoxTracker multiBoxTracker;
    private int sensorOrientation;

    private static final boolean MAINTAIN_ASPECT = false;
    private static final float TEXT_SIZE_DIP = 10;
    private Bitmap rgbBitmap;
    private Interpreter tflite;

    @Override
    public void onCreate() {
        super.onCreate();
        try {
            faceClassifier =
                    TFLiteFaceRecognition.create(
                            getAssets(),
                            "facenet.tflite",
                            TF_OD_API_INPUT_SIZE2,
                            false,getApplicationContext());

        } catch (final IOException e) {
            e.printStackTrace();
            Toast toast =
                    Toast.makeText(
                            getApplicationContext(), "Classifier could not be initialized", Toast.LENGTH_SHORT);
            toast.show();
        }

        // Inflate the floating widget layout
        floatingView = LayoutInflater.from(this).inflate(R.layout.floating_widget, null);
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);

        // Add the floating view to the WindowManager
        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                android.graphics.PixelFormat.TRANSLUCENT);
        params.x = 0;
        params.y = 100;

        windowManager.addView(floatingView, params);
        // Add touch listener to make the widget draggable
        floatingView.setOnTouchListener(new View.OnTouchListener() {
            private int lastAction;
            private int initialX, initialY;
            private float initialTouchX, initialTouchY;

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        // Remember the initial position
                        initialX = params.x;
                        initialY = params.y;
                        initialTouchX = event.getRawX();
                        initialTouchY = event.getRawY();
                        lastAction = MotionEvent.ACTION_DOWN;
                        return true;

                    case MotionEvent.ACTION_MOVE:
                        // Calculate the new position
                        params.x = initialX + (int) (event.getRawX() - initialTouchX);
                        params.y = initialY + (int) (event.getRawY() - initialTouchY);

                        // Update the layout with the new position
                        windowManager.updateViewLayout(floatingView, params);
                        lastAction = MotionEvent.ACTION_MOVE;
                        return true;

                    case MotionEvent.ACTION_UP:
                        // If the last action was a move, consume the event
                        if (lastAction == MotionEvent.ACTION_MOVE) {
                            return true;
                        }
                        break;
                }
                return false;
            }
        });

        // Initialize components
        surfaceView = floatingView.findViewById(R.id.surface_view);
        surfaceView.getHolder().addCallback(new SurfaceHolder.Callback() {
            @Override
            public void surfaceCreated(@NonNull SurfaceHolder holder) {
                setupCamera();
            }

            @Override
            public void surfaceChanged(@NonNull SurfaceHolder holder, int format, int width, int height) {}

            @Override
            public void surfaceDestroyed(@NonNull SurfaceHolder holder) {}
        });

        trackingOverlay = floatingView.findViewById(R.id.tracking_overlay);
        widgetText = floatingView.findViewById(R.id.camera_text);

        setupCamera();

        // Initialize background thread for image processing
        startBackgroundThread();

        // Set up face detector
        FaceDetectorOptions options = new FaceDetectorOptions.Builder()
                .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST)
                .setClassificationMode(FaceDetectorOptions.CLASSIFICATION_MODE_ALL)
                .setContourMode(FaceDetectorOptions.CONTOUR_MODE_ALL)
                .build();
        faceDetector = FaceDetection.getClient(options);

        // Set up MultiBoxTracker
        multiBoxTracker = new MultiBoxTracker(this);

        // Callback for drawing detected faces on OverlayView
        trackingOverlay.addCallback(canvas -> multiBoxTracker.draw(canvas));

        // Initialize the TensorFlow Lite model for face recognition
        try {
            tflite = new Interpreter(loadModelFile("facenet.tflite"));
        } catch (Exception e) {
            Log.e(TAG, "Error loading TensorFlow model: " + e.getMessage());
        }
    }

    private void setupCamera() {
        CameraManager cameraManager = (CameraManager) getSystemService(Context.CAMERA_SERVICE);
        try {
            String cameraId = getFrontCameraId(cameraManager);
            if (cameraId == null) {
                Log.e(TAG, "No front camera found");
                return;
            }

            // Initialize ImageReader
            imageReader = ImageReader.newInstance(640, 480, ImageFormat.YUV_420_888, 2);
            imageReader.setOnImageAvailableListener(reader -> {
                try (Image image = reader.acquireLatestImage()) {
                    if (image == null) return;
                    processImage(image);
                }
            }, backgroundHandler);

            // Open the front-facing camera
            if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                Log.e(TAG, "Camera permission not granted");
                return;
            }
            cameraManager.openCamera(cameraId, new CameraDevice.StateCallback() {
                @Override
                public void onOpened(@NonNull CameraDevice camera) {
                    cameraDevice = camera;
                    Log.i("JAYYY","camera found");
                    startCameraPreview();
                }

                @Override
                public void onDisconnected(@NonNull CameraDevice camera) {
                    camera.close();
                }

                @Override
                public void onError(@NonNull CameraDevice camera, int error) {
                    Log.e(TAG, "Camera error: " + error);
                }
            }, backgroundHandler);
        } catch (CameraAccessException e) {
            Log.e(TAG, "Error setting up camera: " + e.getMessage());
        }
    }

    private void startCameraPreview() {
        try {
            CaptureRequest.Builder requestBuilder = cameraDevice.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW);

            // Add both surfaces to the request
            Surface previewSurface = surfaceView.getHolder().getSurface();
            requestBuilder.addTarget(previewSurface);
            requestBuilder.addTarget(imageReader.getSurface());

            cameraDevice.createCaptureSession(
                    List.of(previewSurface, imageReader.getSurface()),
                    new CameraCaptureSession.StateCallback() {
                        @Override
                        public void onConfigured(@NonNull CameraCaptureSession session) {
                            try {
                                session.setRepeatingRequest(requestBuilder.build(), null, backgroundHandler);
                                Log.i(TAG, "Camera preview started");
                            } catch (CameraAccessException e) {
                                Log.e(TAG, "Error starting camera preview: " + e.getMessage());
                            }
                        }

                        @Override
                        public void onConfigureFailed(@NonNull CameraCaptureSession session) {
                            Log.e(TAG, "Failed to configure camera session");
                        }
                    },
                    backgroundHandler
            );
        } catch (CameraAccessException e) {
            Log.e(TAG, "Error starting camera preview: " + e.getMessage());
        }
    }

    private void processImage(Image image) {
        if (rgbBitmap == null) {
            rgbBitmap = Bitmap.createBitmap(640, 480, Bitmap.Config.ARGB_8888);
        }

        // Extract YUV planes
        ByteBuffer yBuffer = image.getPlanes()[0].getBuffer();
        ByteBuffer uBuffer = image.getPlanes()[1].getBuffer();
        ByteBuffer vBuffer = image.getPlanes()[2].getBuffer();

        // Convert ByteBuffer to byte[]
        byte[] yData = new byte[yBuffer.remaining()];
        byte[] uData = new byte[uBuffer.remaining()];
        byte[] vData = new byte[vBuffer.remaining()];
        yBuffer.get(yData);
        uBuffer.get(uData);
        vBuffer.get(vData);

        // Initialize output array for ARGB data
        int[] out = new int[640 * 480];

        // Convert YUV to ARGB
        ImageUtils.convertYUV420ToARGB8888(
                yData,
                uData,
                vData,
                640,
                480,
                image.getPlanes()[0].getRowStride(),
                image.getPlanes()[1].getRowStride(),
                image.getPlanes()[1].getPixelStride(),
                out
        );

        // Update Bitmap with ARGB data
        rgbBitmap.setPixels(out, 0, 640, 0, 0, 640, 480);
        mappedRecognitions = new ArrayList<>();

        // Create InputImage for ML Kit Face Detection
        InputImage inputImage = InputImage.fromBitmap(rgbBitmap, 0);
        faceDetector.process(inputImage)
                .addOnSuccessListener(faces -> {
                    List<FaceClassifier.Recognition> recognitions = new ArrayList<>();
                    for (Face face : faces) {
                        Log.i("JAYYY","face detected");
                        Rect bounds = face.getBoundingBox();
                        performFaceRecognition(face);
                    }

                    multiBoxTracker.trackResults(mappedRecognitions, 10);
                    trackingOverlay.postInvalidate();
                })
                .addOnFailureListener(e -> Log.e(TAG, "Face detection failed: " + e.getMessage()));
    }
    List<FaceClassifier.Recognition> mappedRecognitions;

    public void performFaceRecognition(Face face){
        //TODO crop the face
        Rect bounds = face.getBoundingBox();
        if(bounds.top<0){
            bounds.top = 0;
        }
        if(bounds.left<0){
            bounds.left = 0;
        }
        int cropSize = CROP_SIZE;

        croppedBitmap = Bitmap.createBitmap(cropSize, cropSize, Bitmap.Config.ARGB_8888);

        if(bounds.left+bounds.width()>croppedBitmap.getWidth()){
            bounds.right = croppedBitmap.getWidth()-1;
        }
        if(bounds.top+bounds.height()>croppedBitmap.getHeight()){
            bounds.bottom = croppedBitmap.getHeight()-1;
        }

        Bitmap crop = Bitmap.createBitmap(croppedBitmap,
                bounds.left,
                bounds.top,
                bounds.width(),
                bounds.height());
        crop = Bitmap.createScaledBitmap(crop,TF_OD_API_INPUT_SIZE2,TF_OD_API_INPUT_SIZE2,false);


        boolean registerFace=false;


        RectF location = new RectF(bounds);
        Log.d("JAYYY","bounds detected"+bounds);
        int previewHeight = 0,previewWidth = 0;

        if (bounds != null) {
            cropToFrameTransform = new Matrix();
            frameToCropTransform =
                    ImageUtils.getTransformationMatrix(
                            previewWidth, previewHeight,
                            cropSize, cropSize,
                            sensorOrientation, MAINTAIN_ASPECT);
            frameToCropTransform.invert(cropToFrameTransform);
            cropToFrameTransform.mapRect(location);
//            FaceClassifier.Recognition recognition = new FaceClassifier.Recognition(face.getTrackingId()+"");

            final FaceClassifier.Recognition result = faceClassifier.recognizeImage(crop, registerFace);
            String nameOfPerson;
            if (result.getDistance()>0.75f){
                nameOfPerson=result.getTitle();
            }else {
                nameOfPerson="Unknown";
            }

            Log.d("JAYYY","NAME : "+nameOfPerson);

        }

    }

    private String getFrontCameraId(CameraManager manager) throws CameraAccessException {
        for (String cameraId : manager.getCameraIdList()) {
            CameraCharacteristics characteristics = manager.getCameraCharacteristics(cameraId);
            if (characteristics.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_FRONT) {
                return cameraId;
            }
        }
        return null;
    }

    private MappedByteBuffer loadModelFile(String modelFileName) throws Exception {
        AssetFileDescriptor fileDescriptor = getAssets().openFd(modelFileName);
        FileInputStream inputStream = fileDescriptor.createInputStream();
        FileChannel channel = inputStream.getChannel();
        long startOffset = fileDescriptor.getStartOffset();
        long declaredLength = fileDescriptor.getDeclaredLength();
        return channel.map(FileChannel.MapMode.READ_ONLY, startOffset, declaredLength);
    }

    private void startBackgroundThread() {
        backgroundThread = new HandlerThread("CameraBackground");
        backgroundThread.start();
        backgroundHandler = new Handler(backgroundThread.getLooper());

    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (cameraDevice != null) {
            cameraDevice.close();
        }
        if (backgroundThread != null) {
            backgroundThread.quitSafely();
        }
        if (floatingView != null) {
            windowManager.removeView(floatingView);
        }
        if (faceDetector != null) {
            faceDetector.close();
        }
        windowManager.removeView(floatingView);
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
