package com.example.navigo;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import android.Manifest;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {
    private static final String TAG = "MainActivity";

    private static final int PERMISSIONS_REQUEST_LOCATION = 100;
    private static final int PERMISSIONS_REQUEST_BACKGROUND_LOCATION = 101;
    private TextView statusTextView;

    private ArrayList<String> installedAppsList;
    private ArrayAdapter<String> listAdapter;
    private ListView appListView;

    private BroadcastReceiver appInstalledReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent.getAction() != null && intent.getAction().equals("com.example.appinstalldetector.APP_INSTALLED")) {
                String appName = intent.getStringExtra("app_name");
                String packageName = intent.getStringExtra("package_name");

                // Get current time
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
                String currentTime = sdf.format(new Date());

                String entryText = currentTime + " - " + appName + " (" + packageName + ")";
                Log.d(TAG, "Adding to list: " + entryText);

                // Add to the list and notify adapter on UI thread
                runOnUiThread(() -> {
                    installedAppsList.add(0, entryText); // Add at the top of the list
                    listAdapter.notifyDataSetChanged();
                });
            }
        }
    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        statusTextView = findViewById(R.id.status_text);

        // Check and request location permissions
        checkAndRequestLocationPermissions();

// Initialize the list and adapter
        installedAppsList = new ArrayList<>();
        appListView = findViewById(R.id.app_list);

        // Add a welcome message to show the list is working
        installedAppsList.add("Waiting for app installations...");

        // Create and set the adapter
        listAdapter = new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1,
                installedAppsList);
        appListView.setAdapter(listAdapter);

        // Register for system package broadcasts in the manifest
        // We'll also register for our custom broadcast in onResume



    }

    @Override
    protected void onResume() {
        super.onResume();

        // Register for our custom broadcast (from AppInstallReceiver to this activity)
        IntentFilter filter = new IntentFilter("com.example.appinstalldetector.APP_INSTALLED");

        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(appInstalledReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(appInstalledReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
        }

        Log.d(TAG, "Receiver registered");
    }

    @Override
    protected void onPause() {
        super.onPause();

        // Unregister our receiver
        try {
            unregisterReceiver(appInstalledReceiver);
            Log.d(TAG, "Receiver unregistered");
        } catch (IllegalArgumentException e) {
            Log.e(TAG, "Error unregistering receiver", e);
        }
    }
    private void checkAndRequestLocationPermissions() {
        List<String> permissionsToRequest = new ArrayList<>();

        // Check for basic location permissions
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            permissionsToRequest.add(Manifest.permission.ACCESS_FINE_LOCATION);
        }

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            permissionsToRequest.add(Manifest.permission.ACCESS_COARSE_LOCATION);
        }

        // Request basic location permissions if needed
        if (!permissionsToRequest.isEmpty()) {
            statusTextView.setText("Requesting location permissions...");
            ActivityCompat.requestPermissions(this,
                    permissionsToRequest.toArray(new String[0]),
                    PERMISSIONS_REQUEST_LOCATION);
        } else {
            // Basic location permissions already granted, check for background location
            checkBackgroundLocationPermission();
        }
    }

    private void checkBackgroundLocationPermission() {
        // Background location permission is only available in Android 10 (API 29) and higher
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_BACKGROUND_LOCATION)
                    != PackageManager.PERMISSION_GRANTED) {
                statusTextView.setText("Requesting background location permission...");

                // Request background location permission
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.ACCESS_BACKGROUND_LOCATION},
                        PERMISSIONS_REQUEST_BACKGROUND_LOCATION);
            } else {
                // All permissions granted
                statusTextView.setText("All location permissions granted!");
            }
        } else {
            // For devices with Android 9 (API 28) or lower, all location permissions granted
            statusTextView.setText("All location permissions granted!");
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions,
                                           int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == PERMISSIONS_REQUEST_LOCATION) {
            boolean allGranted = true;
            for (int result : grantResults) {
                if (result != PackageManager.PERMISSION_GRANTED) {
                    allGranted = false;
                    break;
                }
            }

            if (allGranted) {
                // All basic location permissions granted, check for background location
                Toast.makeText(this, "Location permissions granted!", Toast.LENGTH_SHORT).show();
                checkBackgroundLocationPermission();
            } else {
                // Some or all permissions were denied
                statusTextView.setText("Location permissions denied.\nApp functionality will be limited.");
                Toast.makeText(this, "Location permissions denied", Toast.LENGTH_SHORT).show();
            }
        } else if (requestCode == PERMISSIONS_REQUEST_BACKGROUND_LOCATION) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Background location permission granted
                statusTextView.setText("All location permissions granted (including background)!");
                Toast.makeText(this, "Background location permission granted!", Toast.LENGTH_SHORT).show();
            } else {
                // Background location permission denied
                statusTextView.setText("Basic location permissions granted,\nbut background location denied.");
                Toast.makeText(this, "Background location permission denied", Toast.LENGTH_SHORT).show();
            }
        }
    }




}