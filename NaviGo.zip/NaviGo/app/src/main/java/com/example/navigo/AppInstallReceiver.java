package com.example.navigo;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.util.Log;
import android.widget.Toast;

public class AppInstallReceiver extends BroadcastReceiver {
    private static final String TAG = "AppInstallDetector";

    @Override
    public void onReceive(Context context, Intent intent) {
        // Check if the action is for package added
        if (intent.getAction() != null && intent.getAction().equals(Intent.ACTION_PACKAGE_ADDED)) {
            // Get the package name from the intent data
            String packageName = intent.getData().getSchemeSpecificPart();

            try {
                // Get the application info to retrieve the app name
                PackageManager packageManager = context.getPackageManager();
                String appName = packageManager.getApplicationLabel(
                        packageManager.getApplicationInfo(packageName, 0)).toString();

                // Log the installed app name
                Log.d(TAG, "New app installed: " + appName + " (Package: " + packageName + ")");

                // Send broadcast to MainActivity with the app info
                Intent mainActivityIntent = new Intent("com.example.appinstalldetector.APP_INSTALLED");
                mainActivityIntent.putExtra("app_name", appName);
                mainActivityIntent.putExtra("package_name", packageName);
                context.sendBroadcast(mainActivityIntent);

            } catch (PackageManager.NameNotFoundException e) {
                Log.e(TAG, "Error getting app name", e);
            }
        }
    }
}