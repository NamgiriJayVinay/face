package com.example.navigo;

import android.Manifest;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.provider.Settings;
import android.text.TextUtils;
import android.util.Log;
import android.view.accessibility.AccessibilityManager;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "JAYY";
    private TextView logTextView;
    private Button accessibilityButton;
    public static final String PREFS_NAME = "AppInstallLogs";
    public static final String LOGS_KEY = "install_logs";
    public static final String ACTION_APP_INSTALLED = "com.example.navigo.APP_INSTALLED";

    private BroadcastReceiver logUpdateReceiver;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        logTextView = findViewById(R.id.logTextView);
        accessibilityButton = findViewById(R.id.accessibilityButton);

        // Setup receiver for log updates
        setupLogUpdateReceiver();

        // Start foreground service
        startService(new Intent(this, AppDetectorService.class));

        // Update UI based on accessibility status
        updateAccessibilityButtonState();

        // Setup button click to open accessibility settings
        accessibilityButton.setOnClickListener(v -> {
            Intent intent = new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS);
            startActivity(intent);
            Toast.makeText(this, "Please enable 'App Installation Logger' in Accessibility Settings",
                    Toast.LENGTH_LONG).show();
        });

        // Display logs
        displayLogs();
    }

    private void setupLogUpdateReceiver() {
        logUpdateReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                Log.d(TAG, "Received broadcast to update logs");
                if (ACTION_APP_INSTALLED.equals(intent.getAction())) {
                    displayLogs();
                }
            }
        };
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Register receiver
        LocalBroadcastManager.getInstance(this).registerReceiver(
                logUpdateReceiver, new IntentFilter(ACTION_APP_INSTALLED));

        // Update UI
        updateAccessibilityButtonState();
        displayLogs();
    }

    @Override
    protected void onPause() {
        super.onPause();
        // Unregister receiver
        LocalBroadcastManager.getInstance(this).unregisterReceiver(logUpdateReceiver);
    }

    private void updateAccessibilityButtonState() {
        if (isAccessibilityServiceEnabled()) {
            accessibilityButton.setText("Accessibility Service Enabled");
            accessibilityButton.setEnabled(false);
        } else {
            accessibilityButton.setText("Enable Accessibility Service");
            accessibilityButton.setEnabled(true);
        }
    }

    private boolean isAccessibilityServiceEnabled() {
        AccessibilityManager am = (AccessibilityManager) getSystemService(Context.ACCESSIBILITY_SERVICE);
        List<AccessibilityServiceInfo> enabledServices = am.getEnabledAccessibilityServiceList(
                AccessibilityServiceInfo.FEEDBACK_ALL_MASK);

        String myServiceName = getPackageName() + "/.AppMonitorService";

        for (AccessibilityServiceInfo service : enabledServices) {
            String serviceId = service.getId();
            if (serviceId.equals(myServiceName)) {
                return true;
            }
        }
        return false;
    }

    private void displayLogs() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        String logs = prefs.getString(LOGS_KEY, "No app installations logged yet");
        logTextView.setText(logs);
        Log.d(TAG, "Updated logs on UI");
    }
}