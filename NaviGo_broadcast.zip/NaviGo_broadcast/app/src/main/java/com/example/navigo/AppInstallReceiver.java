package com.example.navigo;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.util.Log;

import androidx.localbroadcastmanager.content.LocalBroadcastManager;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class AppInstallReceiver extends BroadcastReceiver {
    private static final String TAG = "JAYY";
    private static final String PREFS_NAME = "AppInstallLogs";
    private static final String LOGS_KEY = "install_logs";

    @Override
    public void onReceive(Context context, Intent intent) {
        Log.d(TAG, "AppInstallReceiver: onReceive called with action: " + intent.getAction());

        if (intent.getAction() == null || !intent.getAction().equals(Intent.ACTION_PACKAGE_ADDED)) {
            Log.d(TAG, "Not a package added intent, ignoring");
            return;
        }

        // Extract the package name of the newly installed app
        String packageName = intent.getData().getSchemeSpecificPart();
        Log.d(TAG, "New app installed: " + packageName);

        // Get the app name
        String appName = getAppName(context, packageName);
        Log.d(TAG, "App name: " + appName);

        // Save the installation log
        saveAppInstallLog(context, appName, packageName);

        // Notify MainActivity to update its display - use the correct action constant!
        Intent localIntent = new Intent(MainActivity.ACTION_APP_INSTALLED);
        LocalBroadcastManager.getInstance(context).sendBroadcast(localIntent);
        Log.d(TAG, "Broadcast sent to update UI");
    }

    private String getAppName(Context context, String packageName) {
        try {
            PackageManager pm = context.getPackageManager();
            ApplicationInfo ai = pm.getApplicationInfo(packageName, 0);
            return pm.getApplicationLabel(ai).toString();
        } catch (PackageManager.NameNotFoundException e) {
            Log.e(TAG, "Could not get app name for package: " + packageName, e);
            return packageName; // Fallback to package name if app name can't be found
        }
    }

    private void saveAppInstallLog(Context context, String appName, String packageName) {
        // Format the current time
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
        String timestamp = sdf.format(new Date());

        // Create the log entry
        String logEntry = timestamp + " - " + appName + " (" + packageName + ")";
        Log.d(TAG, "Created log entry: " + logEntry);

        // Get the existing logs
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        String existingLogs = prefs.getString(LOGS_KEY, "");

        // Append new log at the beginning
        String updatedLogs;
        if (existingLogs.isEmpty() || existingLogs.equals("No app installations detected yet")) {
            updatedLogs = logEntry;
        } else {
            updatedLogs = logEntry + "\n" + existingLogs;
        }

        // Save back to SharedPreferences
        SharedPreferences.Editor editor = prefs.edit();
        editor.putString(LOGS_KEY, updatedLogs);
        editor.apply();

        Log.d(TAG, "Saved app install log to SharedPreferences");
    }
}