package com.example.navigo;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Build;
import android.os.IBinder;
import android.util.Log;

import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;
public class AppLoggerService extends Service {
    private static final String TAG = "JAYY";
    private static final int NOTIFICATION_ID = 1;
    private static final String CHANNEL_ID = "app_logger_channel";

    private AppInstallReceiver dynamicReceiver;

    @Override
    public void onCreate() {
        super.onCreate();
        Log.d(TAG, "Service created - registering dynamic receiver");

        // Try adding explicit filter for packages
        dynamicReceiver = new AppInstallReceiver();
        IntentFilter filter = new IntentFilter();
        filter.addAction(Intent.ACTION_PACKAGE_ADDED);
        filter.addDataScheme("package");
        registerReceiver(dynamicReceiver, filter);

        Log.d(TAG, "Dynamic receiver registered");
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Log.d(TAG, "Service started");

        // Create and display the notification for foreground service
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            createNotificationChannel();
        }
        monitorPackages();
        Notification notification = createNotification();
        startForeground(NOTIFICATION_ID, notification);

        return START_STICKY; // Restart if system kills the service
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null; // We don't provide binding
    }

    @Override
    public void onDestroy() {
        Log.d(TAG, "Service destroyed");

        // Unregister the dynamic receiver
        if (dynamicReceiver != null) {
            unregisterReceiver(dynamicReceiver);
            dynamicReceiver = null;
        }

        super.onDestroy();
    }
    // Add this to your AppLoggerService to directly check for package changes
    private void monitorPackages() {
        Thread monitorThread = new Thread(() -> {
            Log.d(TAG, "Starting package monitor thread");
            while (!Thread.currentThread().isInterrupted()) {
                try {
                    Thread.sleep(5000); // Check every 5 seconds
                    // This is a basic approach for testing - in production you'd use the broadcast
                    Log.d(TAG, "Checking for new packages...");
                    // Could add direct checking here if needed
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
            }
        });
        monitorThread.start();
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    "App Logger Service",
                    NotificationManager.IMPORTANCE_LOW
            );
            channel.setDescription("Background service monitoring app installations");

            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) {
                manager.createNotificationChannel(channel);
            }
        }
    }

    private Notification createNotification() {
        Intent notificationIntent = new Intent(this, MainActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(
                this, 0, notificationIntent, PendingIntent.FLAG_IMMUTABLE);

        return new NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle("App Logger Running")
                .setContentText("Monitoring for new app installations")
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentIntent(pendingIntent)
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .build();
    }
}
