package com.example.navigo;
import android.accessibilityservice.AccessibilityService;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.util.Log;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import androidx.localbroadcastmanager.content.LocalBroadcastManager;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

public class AppMonitorService extends AccessibilityService {

    private static final String TAG = "JAYY";
    private Set<String> detectedPackages = new HashSet<>();

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        // We're looking for events from Play Store or Package Installer
        if (event.getPackageName() == null) return;

        String sourcePackage = event.getPackageName().toString();
        Log.d(TAG, "Accessibility event from: " + sourcePackage);

        // Check if this is from an installer app or settings (for uninstalls)
        if (sourcePackage.equals("com.android.packageinstaller") ||
                sourcePackage.equals("com.android.vending") ||
                sourcePackage.equals("com.google.android.packageinstaller") ||
                sourcePackage.equals("com.android.settings")) {

            // Process app installation/uninstallation events
            processAppEvent(event);
        }
    }

    private void processAppEvent(AccessibilityEvent event) {
        if (event.getSource() == null) return;

        AccessibilityNodeInfo rootNode = event.getSource();
        String eventText = "";

        // Get text from the event
        if (event.getText() != null && !event.getText().isEmpty()) {
            eventText = event.getText().toString().toLowerCase();
            Log.d(TAG, "Event text: " + eventText);

            // Look for uninstall confirmation or success text
            boolean isUninstallEvent = eventText.contains("uninstall") ||
                    eventText.contains("remove") ||
                    eventText.contains("delete");

            // Check for changes in installed apps regardless
            checkForChangesInInstalledApps();
        }

        rootNode.recycle(); // Always recycle the node when done
    }

    private void checkForChangesInInstalledApps() {
        final PackageManager pm = getPackageManager();
        List<ApplicationInfo> currentApps = pm.getInstalledApplications(0);
        Set<String> currentPackages = new HashSet<>();

        // Build current package list (excluding system apps)
        for (ApplicationInfo app : currentApps) {
            if ((app.flags & ApplicationInfo.FLAG_SYSTEM) == 0) {
                currentPackages.add(app.packageName);
            }
        }

        // First, check for new installations
        for (String packageName : currentPackages) {
            if (!detectedPackages.contains(packageName)) {
                // This is a new app!
                try {
                    ApplicationInfo appInfo = pm.getApplicationInfo(packageName, 0);
                    String appName = pm.getApplicationLabel(appInfo).toString();
                    logAppEvent(packageName, appName, true); // true = installed
                    detectedPackages.add(packageName);
                } catch (PackageManager.NameNotFoundException e) {
                    Log.e(TAG, "Error getting app name for: " + packageName, e);
                }
            }
        }

        // Then check for uninstallations
        Set<String> uninstalledPackages = new HashSet<>(detectedPackages);
        uninstalledPackages.removeAll(currentPackages);

        for (String packageName : uninstalledPackages) {
            // We don't have app name anymore, so use package name
            logAppEvent(packageName, packageName, false); // false = uninstalled
            detectedPackages.remove(packageName);
        }
    }

    private void logAppEvent(String packageName, String appName, boolean isInstallation) {
        String eventType = isInstallation ? "installed" : "uninstalled";
        Log.d(TAG, "App " + eventType + ": " + appName + " (" + packageName + ")");

        // Format current time
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
        String timestamp = sdf.format(new Date());

        // Create log entry
        String logEntry = timestamp + " - " + appName + " (" + packageName + ") " + eventType;

        // Save to SharedPreferences
        SharedPreferences prefs = getSharedPreferences(MainActivity.PREFS_NAME, MODE_PRIVATE);
        String existingLogs = prefs.getString(MainActivity.LOGS_KEY, "");

        // Append new log at the beginning
        String updatedLogs;
        if (existingLogs.isEmpty() || existingLogs.equals("No app installations logged yet")) {
            updatedLogs = logEntry;
        } else {
            updatedLogs = logEntry + "\n" + existingLogs;
        }

        // Save back to SharedPreferences
        SharedPreferences.Editor editor = prefs.edit();
        editor.putString(MainActivity.LOGS_KEY, updatedLogs);
        editor.apply();

        // Notify MainActivity to update its display
        Intent localIntent = new Intent(MainActivity.ACTION_APP_INSTALLED);
        LocalBroadcastManager.getInstance(this).sendBroadcast(localIntent);
    }

    @Override
    public void onInterrupt() {
        Log.d(TAG, "Accessibility service interrupted");
    }

    @Override
    public void onServiceConnected() {
        super.onServiceConnected();
        Log.d(TAG, "Accessibility service connected");

        // Initialize with current installed non-system apps
        PackageManager pm = getPackageManager();
        List<ApplicationInfo> apps = pm.getInstalledApplications(0);

        for (ApplicationInfo app : apps) {
            // Skip system apps
            if ((app.flags & ApplicationInfo.FLAG_SYSTEM) != 0) {
                continue;
            }

            detectedPackages.add(app.packageName);
        }

        Log.d(TAG, "Initialized with " + detectedPackages.size() + " existing apps");
    }
}